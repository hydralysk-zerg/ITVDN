a_str = "10"
a_int = int(a_str)

b_int = 10
b_str = str(b_int)

c_int = 25
c_float = float(c_int)

d_list = []
d_bool = bool(d_list)

d_list_2 = [1, 2, 3]
d_bool_2 = bool(d_list_2)

e_list = [1, 2, 2, 2, 3]
e_set = set(e_list)
