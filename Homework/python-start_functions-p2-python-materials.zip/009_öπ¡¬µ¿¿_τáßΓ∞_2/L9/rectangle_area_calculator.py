def area_calculator(height, length):
    return height * length


h1 = 10
l1 = 3
area = area_calculator(h1, l1)
print(area)
